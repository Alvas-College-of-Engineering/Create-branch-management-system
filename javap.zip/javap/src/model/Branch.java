package model;

public class Branch {
    private int branchId;
    private String branchName;
    private String location;
    private String managerName;

    public Branch(int branchId, String branchName, String location, String managerName) {
        this.branchId = branchId;
        this.branchName = branchName;
        this.location = location;
        this.managerName = managerName;
    }

    public int getBranchId() { return branchId; }
    public String getBranchName() { return branchName; }
    public String getLocation() { return location; }
    public String getManagerName() { return managerName; }

    public void setBranchName(String branchName) { this.branchName = branchName; }
    public void setLocation(String location) { this.location = location; }
    public void setManagerName(String managerName) { this.managerName = managerName; }
}



//javac -d ../bin model/*.java service/*.java ui/*.java