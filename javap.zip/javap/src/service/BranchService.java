package service;

import model.Branch;
import java.util.ArrayList;
import java.util.List;

public class BranchService {
    private List<Branch> branches = new ArrayList<>();

    public void addBranch(Branch b) {
        branches.add(b);
    }

    public List<Branch> getAllBranches() {
        return branches;
    }

    public Branch findBranchById(int id) {
        for (Branch b : branches) {
            if (b.getBranchId() == id) return b;
        }
        return null;
    }
}