package ui;

import model.Branch;
import service.BranchService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class BranchUI extends JFrame {

    private JTextField idField, nameField, locationField, managerField;
    private JTable table;
    private DefaultTableModel model;
    private BranchService service = new BranchService();

    public BranchUI() {
        setTitle("Branch Management System");
        setSize(700, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // 🔹 Input Panel
        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));

        panel.add(new JLabel("Branch ID:"));
        idField = new JTextField();
        panel.add(idField);

        panel.add(new JLabel("Branch Name:"));
        nameField = new JTextField();
        panel.add(nameField);

        panel.add(new JLabel("Location:"));
        locationField = new JTextField();
        panel.add(locationField);

        panel.add(new JLabel("Manager:"));
        managerField = new JTextField();
        panel.add(managerField);

        add(panel, BorderLayout.NORTH);

        // 🔹 Buttons
        JPanel btnPanel = new JPanel();

        JButton addBtn = new JButton("Add");
        JButton updateBtn = new JButton("Update");
        JButton searchBtn = new JButton("Search");
        JButton viewBtn = new JButton("View All");

        btnPanel.add(addBtn);
        btnPanel.add(updateBtn);
        btnPanel.add(searchBtn);
        btnPanel.add(viewBtn);

        add(btnPanel, BorderLayout.CENTER);

        // 🔹 Table
        model = new DefaultTableModel(new String[]{"ID", "Name", "Location", "Manager"}, 0);
        table = new JTable(model);
        add(new JScrollPane(table), BorderLayout.SOUTH);

        // 🔥 BUTTON ACTIONS

        // ADD
        addBtn.addActionListener(e -> {
            int id = Integer.parseInt(idField.getText());
            service.addBranch(new Branch(id, nameField.getText(), locationField.getText(), managerField.getText()));
            refreshTable();
            clearFields();
            JOptionPane.showMessageDialog(this, "Branch Added!");
        });

        // UPDATE (FIXED LOGIC)
        updateBtn.addActionListener(e -> {
            int id = Integer.parseInt(idField.getText());
            Branch b = service.findBranchById(id);

            if (b == null) {
                JOptionPane.showMessageDialog(this, "Branch not available!");
                return; // ✅ stops here
            }

            b.setBranchName(nameField.getText());
            b.setLocation(locationField.getText());
            b.setManagerName(managerField.getText());

            refreshTable();
            clearFields();
            JOptionPane.showMessageDialog(this, "Updated Successfully!");
        });

        // SEARCH
        searchBtn.addActionListener(e -> {
            int id = Integer.parseInt(idField.getText());
            Branch b = service.findBranchById(id);

            if (b == null) {
                JOptionPane.showMessageDialog(this, "Branch not found!");
            } else {
                nameField.setText(b.getBranchName());
                locationField.setText(b.getLocation());
                managerField.setText(b.getManagerName());
            }
        });

        // VIEW
        viewBtn.addActionListener(e -> refreshTable());

        setVisible(true);
    }

    private void refreshTable() {
        model.setRowCount(0);
        for (Branch b : service.getAllBranches()) {
            model.addRow(new Object[]{
                    b.getBranchId(),
                    b.getBranchName(),
                    b.getLocation(),
                    b.getManagerName()
            });
        }
    }

    private void clearFields() {
        idField.setText("");
        nameField.setText("");
        locationField.setText("");
        managerField.setText("");
    }

    public static void main(String[] args) {
        new BranchUI();
    }
}

